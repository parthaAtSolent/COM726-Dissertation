"""Sidebar UI component."""

import streamlit as st
import traceback
from app.ui.sidebar import (
    render_branding,
    render_model_selector,
    new_chat,
    clear_thread_cache,
    get_cached_threads,
    render_thread_row,
    render_delete_confirmation,
    render_rag_panel,
)


def render_sidebar() -> None:
    """Render the complete sidebar."""
    try:
        render_branding()
        render_model_selector()

        if st.sidebar.button("➕ New Chat", use_container_width=True, type="primary"):
            clear_thread_cache()
            new_chat()

        st.sidebar.divider()
        st.sidebar.header("📝 Conversations")

        threads = get_cached_threads()

        print(f"[Sidebar] Rendering {len(threads)} threads")

        if not threads:
            st.sidebar.info("No conversations yet. Start a new chat!")
        else:
            for thread in threads:
                render_thread_row(thread)

        render_delete_confirmation()
        render_rag_panel()

    except Exception as e:
        st.sidebar.error(f"Failed to render sidebar: {str(e)}")
        print(f"Render sidebar error: {traceback.format_exc()}")
