"""config — application-level settings."""

from .settings import (
    BASE_DIR,
    DATA_DIR,
    DEFAULT_MODEL_KEY,
    DEFAULT_THREAD_TITLE,
    MAX_TITLE_LENGTH,
    MYSQL_DATABASE,
    MYSQL_HOST,
    MYSQL_PASSWORD,
    MYSQL_PORT,
    MYSQL_USER,
    STATIC_DIR,
    TEMPLATES_DIR,
    TITLE_PROMPT_MAX_CHARS,
)

__all__ = [
    "BASE_DIR",
    "DATA_DIR",
    "DEFAULT_MODEL_KEY",
    "DEFAULT_THREAD_TITLE",
    "MAX_TITLE_LENGTH",
    "MYSQL_DATABASE",
    "MYSQL_HOST",
    "MYSQL_PASSWORD",
    "MYSQL_PORT",
    "MYSQL_USER",
    "STATIC_DIR",
    "TEMPLATES_DIR",
    "TITLE_PROMPT_MAX_CHARS",
]
